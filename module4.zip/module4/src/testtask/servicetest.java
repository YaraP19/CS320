package testtask;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import task.taskservice;

public class servicetest {

    private taskservice service;

    @BeforeEach
    void setUp() {

        service = new taskservice();

        taskservice.tasks.clear();
    }

    @Test
    void testAddTask() {

        service.addUniqueTask(
                "Homework",
                "Finish Project");

        assertEquals(1,
                taskservice.tasks.size());
    }

    @Test
    void testDeleteTask() {

        service.addUniqueTask(
                "Homework",
                "Finish Project");

        assertTrue(
                taskservice.tasks.containsKey("0"));

        service.deleteTasks("0");

        assertFalse(
                taskservice.tasks.containsKey("0"));
    }

    @Test
    void testUpdateTask() {

        service.addUniqueTask(
                "Homework",
                "Finish Project");

        service.updateTasks(
                "0",
                "Updated Homework",
                "Updated Description");

        assertEquals(
                "Updated Homework",
                taskservice.tasks.get("0").getName());

        assertEquals(
                "Updated Description",
                taskservice.tasks.get("0").getDescription());
    }

    @Test
    void testDeleteInvalidTaskID() {

        service.deleteTasks("999");

        assertEquals(
                0,
                taskservice.tasks.size());
    }

    @Test
    void testUpdateInvalidTaskID() {

        service.updateTasks(
                "999",
                "Name",
                "Description");

        assertEquals(
                0,
                taskservice.tasks.size());
    }
}