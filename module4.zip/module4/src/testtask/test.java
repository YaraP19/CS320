package testtask;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import task.task;

public class test {

    @Test
    void testCreateValidTask() {

        task testTask = new task();

        testTask.Task(
                "123",
                "Homework",
                "Finish Project One");

        assertEquals(123, testTask.getUniqueID());
        assertEquals("Homework", testTask.getName());
        assertEquals("Finish Project One",
                testTask.getDescription());
    }

    @Test
    void testInvalidIDNull() {

        task testTask = new task();

        assertThrows(IllegalArgumentException.class, () -> {
            testTask.Task(
                    null,
                    "Homework",
                    "Description");
        });
    }

    @Test
    void testInvalidIDTooLong() {

        task testTask = new task();

        assertThrows(IllegalArgumentException.class, () -> {
            testTask.Task(
                    "12345678901",
                    "Homework",
                    "Description");
        });
    }

    @Test
    void testInvalidNameNull() {

        task testTask = new task();

        assertThrows(IllegalArgumentException.class, () -> {
            testTask.Task(
                    "123",
                    null,
                    "Description");
        });
    }

    @Test
    void testInvalidNameTooLong() {

        task testTask = new task();

        assertThrows(IllegalArgumentException.class, () -> {
            testTask.Task(
                    "123",
                    "ThisNameIsWayTooLongForTheRequirement",
                    "Description");
        });
    }

    @Test
    void testInvalidDescriptionNull() {

        task testTask = new task();

        assertThrows(IllegalArgumentException.class, () -> {
            testTask.Task(
                    "123",
                    "Homework",
                    null);
        });
    }

    @Test
    void testInvalidDescriptionTooLong() {

        task testTask = new task();

        assertThrows(IllegalArgumentException.class, () -> {
            testTask.Task(
                    "123",
                    "Homework",
                    "This description is definitely longer than fifty characters and should fail validation");
        });
    }

    @Test
    void testUpdateName() {

        task testTask = new task();

        testTask.Task(
                "123",
                "Homework",
                "Description");

        testTask.setName("Updated Name");

        assertEquals("Updated Name",
                testTask.getName());
    }

    @Test
    void testUpdateDescription() {

        task testTask = new task();

        testTask.Task(
                "123",
                "Homework",
                "Description");

        testTask.setDescription("Updated Description");

        assertEquals("Updated Description",
                testTask.getDescription());
    }
}


