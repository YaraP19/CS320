package task;


import java.util.HashMap;

public class taskservice {
int currentIDNum = 0; //pseudo GUID
	
	public static HashMap<String, task> tasks = new HashMap<String, task>();
	
	public void addUniqueTask(String _name, String _description) {

		String stringID = Integer.toString(currentIDNum);		
		task temptask = new task ();
		tasks.put(stringID, temptask);	

		++currentIDNum;		
	}
	
	public void deleteTasks(String _ID) {
		
		if(tasks.containsKey(_ID)) {			
			tasks.remove(_ID);
		}		
	}
	
	public void updateTasks(String _ID, String _newName, String _newDescription) {
		
		if(tasks.containsKey(_ID)) {
			
			tasks.get(_ID).setName(_newName);
			tasks.get(_ID).setDescription(_newDescription);
		}
		
	}

}
