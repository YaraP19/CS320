package Step2;

import java.util.HashMap;
import Step1.Task;

public class TaskService {

    private int currentIDNum = 0;
    private final HashMap<String, Task> tasks = new HashMap<>();

    //Adds a new task with unique ID.
     
    public void addUniqueTask(String name, String description) {

        String id = Integer.toString(currentIDNum);

        Task newTask = new Task(id, name, description);

        tasks.put(id, newTask);
        currentIDNum++;
    }

    // Deletes a task by ID.
    
    public void deleteTask(String id) {
        if (!tasks.containsKey(id)) {
            throw new IllegalArgumentException("Task not found: " + id);
        }
        tasks.remove(id);
    }

    // Update existing task's name and description.

    public void updateTask(String id, String newName, String newDescription) {

        Task task = tasks.get(id);

        if (task == null) {
            throw new IllegalArgumentException("Task not found: " + id);
        }

        task.setName(newName);
        task.setDescription(newDescription);
    }

    //Retrieve a task by ID
    
    public Task getTask(String id) {
        return tasks.get(id);
    }
}
