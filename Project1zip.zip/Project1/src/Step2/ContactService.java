package Step2;

import java.util.ArrayList;
import java.util.List;
import Step1.Contact;

public class ContactService {

    private int currentIDNum = 0;
    private final List<Contact> contactList = new ArrayList<>();

    public void addContact(String firstName, String lastName,
                           String phoneNumber, String address) {

        String stringID = Integer.toString(currentIDNum);
        Contact newContact = new Contact(stringID, firstName, lastName, phoneNumber, address);

        contactList.add(newContact);
        currentIDNum++;
    }

    public void deleteContact(String id) {
        boolean removed = contactList.removeIf(c -> c.getContactID().equals(id));
        if (!removed) {
            throw new IllegalArgumentException("Contact not found: " + id);
        }
    }

    //
    public Contact getContact(String contactID) {
        return contactList.stream()
                .filter(c -> c.getContactID().equals(contactID))
                .findFirst()
                .orElse(null);
    }

    public void editFirstName(String id, String newName) {
        Contact c = findContact(id);
        c.setFirstName(newName);
    }

    public void editLastName(String id, String newName) {
        Contact c = findContact(id);
        c.setLastName(newName);
    }

    public void editNumber(String id, String newNumber) {
        Contact c = findContact(id);
        c.setPhoneNumber(newNumber);
    }

    public void editAddress(String id, String newAddress) {
        Contact c = findContact(id);
        c.setAddress(newAddress);
    }

    private Contact findContact(String id) {
        return contactList.stream()
                .filter(c -> c.getContactID().equals(id))
                .findFirst()
                .orElseThrow(() ->
                        new IllegalArgumentException("Contact not found: " + id));
    }
}
