package Step2;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import Step1.Appointment;

public class AppointmentService {

    private final Map<String, Appointment> appointments = new HashMap<>();
    private int idCounter = 0;

    // Create a new appointment 
    public void addUniqueAppointment(Date date, String description) {
        String id = String.valueOf(idCounter++);
        Appointment appt = new Appointment(id, date, description);
        appointments.put(id, appt);
    }

    // Returns the appointment
    public Appointment getAppointment(String id) {
        return appointments.get(id);
    }

    // Deletes appointment if ID does not exist
    public void deleteAppointment(String id) {
        if (!appointments.containsKey(id)) {
            throw new IllegalArgumentException("Appointment not found: " + id);
        }
        appointments.remove(id);
    }

    // Updates appointment if ID does not exist
    public void updateAppointment(String id, Date newDate, String newDescription) {
        if (!appointments.containsKey(id)) {
            throw new IllegalArgumentException("Appointment not found: " + id);
        }
        Appointment appt = appointments.get(id);
        appt.setDate(newDate);
        appt.setDescription(newDescription);
    }
}
