package Step1;

import java.util.Date;

public class Appointment {

    private String uniqueID;
    private Date date;
    private String description;

    //validate the uniqueID

    private final boolean validateID(String uniqueID) {
        return uniqueID != null && uniqueID.length() <= 10;
    }

    //validate the date
 
    private final boolean validateDate(Date _date) {
        if (_date == null) {
            return false;
        }

        Date now = new Date();
        return !_date.before(now);
    }

    //validates the description 
    
    private final boolean validateDescription(String description) {
        return description != null
                && !description.isEmpty()
                && description.length() <= 50;
    }

    public Appointment(String uniqueID, Date date, String description) {

        if (!validateID(uniqueID)) {
            throw new IllegalArgumentException("Invalid ID");
        }

        if (!validateDate(date)) {
            throw new IllegalArgumentException("Invalid date");
        }

        if (!validateDescription(description)) {
            throw new IllegalArgumentException("Invalid description");
        }

        this.uniqueID = uniqueID;
        this.date = date;
        this.description = description;
    }

    public String getUniqueID() {
        return uniqueID;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        if (!validateDate(date)) {
            throw new IllegalArgumentException("Invalid date");
        }
        this.date = date;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        if (!validateDescription(description)) {
            throw new IllegalArgumentException("Invalid description");
        }
        this.description = description;
    }
}
