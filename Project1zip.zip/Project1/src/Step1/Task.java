package Step1;

public class Task {

    private String uniqueID;
    private String name;
    private String description;

    private boolean validateID(String uniqueID) {
        return uniqueID != null && uniqueID.length() <= 10;
    }

    private boolean validateName(String name) {
        return name != null
                && !name.isEmpty()
                && name.length() <= 20;
    }

    private boolean validateDescription(String description) {
        return description != null
                && !description.isEmpty()
                && description.length() <= 50;
    }

    public Task(String uniqueID, String name, String description) {

        if (!validateID(uniqueID)) {
            throw new IllegalArgumentException("Invalid ID");
        }

        if (!validateName(name)) {
            throw new IllegalArgumentException("Invalid name");
        }

        if (!validateDescription(description)) {
            throw new IllegalArgumentException("Invalid description");
        }

        this.uniqueID = uniqueID;
        this.name = name;
        this.description = description;
    }

    public String getUniqueID() {
        return uniqueID;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        if (!validateName(name)) {
            throw new IllegalArgumentException("Invalid name");
        }
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        if (!validateDescription(description)) {
            throw new IllegalArgumentException("Invalid description");
        }
        this.description = description;
    }
}

