package Step2;

import static org.junit.jupiter.api.Assertions.*;

import java.util.Date;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import Step1.Appointment;

public class AppointmentServiceTest {

    private AppointmentService service;

    @BeforeEach
    void setUp() {
        service = new AppointmentService();
    }

    
    void testAddAppointment() {

        Date futureDate = new Date(System.currentTimeMillis() + 86400000);

        service.addUniqueAppointment(futureDate, " Appointment");

        Appointment appt = service.getAppointment("0");

        assertNotNull(appt);
        assertEquals(" Appointment", appt.getDescription());
        assertEquals(futureDate, appt.getDate());
    }

    @Test
    void testAddMultipleAppointments() {

        Date futureDate1 = new Date(System.currentTimeMillis() + 86400000);
        Date futureDate2 = new Date(System.currentTimeMillis() + 172800000);

        service.addUniqueAppointment(futureDate1, "Appointment One");
        service.addUniqueAppointment(futureDate2, "Appointment Two");

        assertNotNull(service.getAppointment("0"));
        assertNotNull(service.getAppointment("1"));
    }

    @Test
    void testDeleteAppointment() {

        Date futureDate = new Date(System.currentTimeMillis() + 86400000);

        service.addUniqueAppointment(futureDate, " Appointment");

        assertNotNull(service.getAppointment("0"));

        service.deleteAppointment("0");

        assertNull(service.getAppointment("0"));
    }

    @Test
    void testDeleteNonExistingAppointmentThrows() {

        Date futureDate = new Date(System.currentTimeMillis() + 86400000);

        service.addUniqueAppointment(futureDate, " Appointment");

        assertThrows(IllegalArgumentException.class, () ->
                service.deleteAppointment("999"));
    }

    @Test
    void testUpdateAppointment() {

        Date futureDate = new Date(System.currentTimeMillis() + 86400000);
        Date newDate = new Date(System.currentTimeMillis() + 172800000);

        service.addUniqueAppointment(futureDate, "Initial Description");

        service.updateAppointment("0", newDate, "Updated Description");

        Appointment appt = service.getAppointment("0");

        assertEquals("Updated Description", appt.getDescription());
        assertEquals(newDate, appt.getDate());
    }

    @Test
    void testUpdateNonExistingAppointmentThrows() {

        Date newDate = new Date(System.currentTimeMillis() + 172800000);

        assertThrows(IllegalArgumentException.class, () ->
                service.updateAppointment("999", newDate, "Doesn't matter"));
    }
}
