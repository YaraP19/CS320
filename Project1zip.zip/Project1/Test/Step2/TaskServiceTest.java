package Step2;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import Step1.Task;

public class TaskServiceTest {

	
    private TaskService service;

    @BeforeEach
    void setUp() {
        service = new TaskService();
    }

    @Test
    void testAddTask() {

        service.addUniqueTask("Complete Assignment",
                "Finish the software testing assignment");

        Task t = service.getTask("0");

        assertNotNull(t);
        assertEquals("Complete Assignment", t.getName());
        assertEquals("Finish the software testing assignment", t.getDescription());
    }

    @Test
    void testAddMultipleTasks() {

        service.addUniqueTask("Task One", "Description One");
        service.addUniqueTask("Task Two", "Description Two");

        assertNotNull(service.getTask("0"));
        assertNotNull(service.getTask("1"));

        assertEquals("Task Two", service.getTask("1").getName());
    }

    @Test
    void testDeleteTask() {

        service.addUniqueTask("Task One", "Description One");

        assertNotNull(service.getTask("0"));

        service.deleteTask("0");

        assertNull(service.getTask("0"));
    }

    @Test
    void testDeleteNonExistingTaskThrows() {

        service.addUniqueTask("Task One", "Description One");

        assertThrows(IllegalArgumentException.class, () ->
                service.deleteTask("99"));
    }

    @Test
    void testUpdateTask() {

        service.addUniqueTask("Original Name", "Original Description");

        service.updateTask("0",
                "Updated Name",
                "Updated Description");

        Task t = service.getTask("0");

        assertEquals("Updated Name", t.getName());
        assertEquals("Updated Description", t.getDescription());
    }

    @Test
    void testUpdateNonExistingTaskThrows() {

        assertThrows(IllegalArgumentException.class, () ->
                service.updateTask("99", "New Name", "New Description"));
    }

    @Test
    void testUpdateTaskWithInvalidName() {

        service.addUniqueTask("Task Name", "Task Description");

        assertThrows(IllegalArgumentException.class, () ->
                service.updateTask("0", "", "Updated Description"));
    }

    @Test
    void testUpdateTaskWithNullName() {

        service.addUniqueTask("Task Name", "Task Description");

        assertThrows(IllegalArgumentException.class, () ->
                service.updateTask("0", null, "Updated Description"));
    }

    @Test
    void testUpdateTaskWithInvalidDescription() {

        service.addUniqueTask("Task Name", "Task Description");

        assertThrows(IllegalArgumentException.class, () ->
                service.updateTask("0", "Updated Name", ""));
    }

    @Test
    void testUpdateTaskWithNullDescription() {

        service.addUniqueTask("Task Name", "Task Description");

        assertThrows(IllegalArgumentException.class, () ->
                service.updateTask("0", "Updated Name", null));
    }

    @Test
    void testUpdateTaskWithLongName() {

        service.addUniqueTask("Task Name", "Task Description");

        assertThrows(IllegalArgumentException.class, () ->
                service.updateTask("0",
                        "ThisTaskNameIsLongerThanTwentyCharacters",
                        "Updated Description"));
    }

    @Test
    void testUpdateTaskWithLongDescription() {

        service.addUniqueTask("Task Name", "Task Description");

        String longDescription =
                "This description is definitely longer than fifty characters allowed.";

        assertThrows(IllegalArgumentException.class, () ->
                service.updateTask("0", "Updated Name", longDescription));
    }
}
