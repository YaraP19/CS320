package Step2;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import Step1.Contact;

public class ContactServiceTest {

    private ContactService service;

    @BeforeEach
    void setUp() {
        service = new ContactService();
    }

    @Test
    void testAddContact() {

        service.addContact("Kay", "Padila", "1234567890", "1125 Pointloma Ave");

        Contact c = service.getContact("0");

        assertNotNull(c);
        assertEquals("Kay", c.getFirstName());
        assertEquals("Padila", c.getLastName());
        assertEquals("1234567890", c.getPhoneNumber());
        assertEquals("1125 Pointloma Ave", c.getAddress());
    }

    @Test
    void testAddMultipleContacts() {

        service.addContact("Kay", "Padila", "1234567890", "1125 Pointloma Ave");
        service.addContact("Lena", "Cruz", "0987654321", "789 Harbor View Rd");

        assertNotNull(service.getContact("0"));
        assertNotNull(service.getContact("1"));

        assertEquals("Lena", service.getContact("1").getFirstName());
    }

    @Test
    void testDeleteContact() {

        service.addContact("Kay", "Padila", "1234567890", "1125 Pointloma Ave");

        assertNotNull(service.getContact("0"));

        service.deleteContact("0");

        assertNull(service.getContact("0"));
    }

    @Test
    void testDeleteNonExistingContactThrows() {

        service.addContact("Kay", "Padila", "1234567890", "1125 Pointloma Ave");

        assertThrows(IllegalArgumentException.class, () ->
                service.deleteContact("99"));
    }

    @Test
    void testEditFirstName() {

        service.addContact("Kay", "Padila", "1234567890", "1125 Pointloma Ave");

        service.editFirstName("0", "Lena");

        assertEquals("Lena", service.getContact("0").getFirstName());
    }

    @Test
    void testEditLastName() {

        service.addContact("Kay", "Padila", "1234567890", "1125 Pointloma Ave");

        service.editLastName("0", "Cruz");

        assertEquals("Cruz", service.getContact("0").getLastName());
    }

    @Test
    void testEditPhoneNumber() {

        service.addContact("Kay", "Padila", "1234567890", "1125 Pointloma Ave");

        service.editNumber("0", "0987654321");

        assertEquals("0987654321", service.getContact("0").getPhoneNumber());
    }

    @Test
    void testEditAddress() {

        service.addContact("Kay", "Padila", "1234567890", "1125 Pointloma Ave");

        service.editAddress("0", "456 Oak Ave");

        assertEquals("456 Oak Ave", service.getContact("0").getAddress());
    }

    @Test
    void testEditFirstNameInvalid() {

        service.addContact("Kay", "Padila", "1234567890", "1125 Pointloma Ave");

        assertThrows(IllegalArgumentException.class, () ->
                service.editFirstName("0", "VeryLongFirstName"));
    }

    @Test
    void testEditLastNameInvalid() {

        service.addContact("Kay", "Padila", "1234567890", "1125 Pointloma Ave");

        assertThrows(IllegalArgumentException.class, () ->
                service.editLastName("0", "VeryLongLastName"));
    }

    @Test
    void testEditPhoneNumberInvalid() {

        service.addContact("Kay", "Padila", "1234567890", "1125 Pointloma Ave");

        assertThrows(IllegalArgumentException.class, () ->
                service.editNumber("0", "123"));
    }

    @Test
    void testEditAddressInvalid() {

        service.addContact("Kay", "Padila", "1234567890", "1125 Pointloma Ave");

        assertThrows(IllegalArgumentException.class, () ->
                service.editAddress("0", "1234567890123456789012345678901"));
    }

    @Test
    void testEditNonExistingContactThrows() {

        assertThrows(IllegalArgumentException.class, () ->
                service.editFirstName("99", "NewName"));
    }
}
