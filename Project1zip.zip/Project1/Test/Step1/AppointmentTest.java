package Step1;

import static org.junit.jupiter.api.Assertions.*;

import java.util.Date;

import org.junit.jupiter.api.Test;

public class AppointmentTest {

    @Test
    void testValidAppointment() {

        Date futureDate =
                new Date(System.currentTimeMillis() + 1000000);

        Appointment appt = new Appointment(
                "12345",
                futureDate,
                " visit");

        assertEquals("12345", appt.getUniqueID());
        assertEquals(futureDate, appt.getDate());
        assertEquals(" visit", appt.getDescription());
    }

    // ID TESTS

    @Test
    void testNullID() {
        Date futureDate =
                new Date(System.currentTimeMillis() + 1000000);

        assertThrows(IllegalArgumentException.class, () ->
                new Appointment(null, futureDate, "Valid description"));
    }

    @Test
    void testIDTooLong() {
        Date futureDate =
                new Date(System.currentTimeMillis() + 1000000);

        assertThrows(IllegalArgumentException.class, () ->
                new Appointment("12345678901", futureDate, "Valid description"));
    }

    // DATE TESTS 

    @Test
    void testNullDate() {

        assertThrows(IllegalArgumentException.class, () ->
                new Appointment("12345", null, "Valid description"));
    }

    @Test
    void testPastDate() {

        Date pastDate =
                new Date(System.currentTimeMillis() - 1000000);

        assertThrows(IllegalArgumentException.class, () ->
                new Appointment("12345", pastDate, "Valid description"));
    }

    // DESCRIPTION TESTS 

    @Test
    void testNullDescription() {

        Date futureDate =
                new Date(System.currentTimeMillis() + 1000000);

        assertThrows(IllegalArgumentException.class, () ->
                new Appointment("12345", futureDate, null));
    }

    @Test
    void testEmptyDescription() {

        Date futureDate =
                new Date(System.currentTimeMillis() + 1000000);

        assertThrows(IllegalArgumentException.class, () ->
                new Appointment("12345", futureDate, ""));
    }

    @Test
    void testDescriptionTooLong() {

        Date futureDate =
                new Date(System.currentTimeMillis() + 1000000);

        String longDesc =
                "This description is definitely way longer than fifty characters allowed in the system";

        assertThrows(IllegalArgumentException.class, () ->
                new Appointment("12345", futureDate, longDesc));
    }

    //SETTER TESTS 

    @Test
    void testSetValidDate() {

        Date futureDate =
                new Date(System.currentTimeMillis() + 1000000);

        Date newDate =
                new Date(System.currentTimeMillis() + 2000000);

        Appointment appt = new Appointment(
                "12345", futureDate, "Valid description");

        appt.setDate(newDate);

        assertEquals(newDate, appt.getDate());
    }

    @Test
    void testSetPastDate() {

        Date futureDate =
                new Date(System.currentTimeMillis() + 1000000);

        Date pastDate =
                new Date(System.currentTimeMillis() - 1000000);

        Appointment appt = new Appointment(
                "12345", futureDate, "Valid description");

        assertThrows(IllegalArgumentException.class, () ->
                appt.setDate(pastDate));
    }

    @Test
    void testSetValidDescription() {

        Date futureDate =
                new Date(System.currentTimeMillis() + 1000000);

        Appointment appt = new Appointment(
                "12345", futureDate, "Valid description");

        appt.setDescription("Updated description");

        assertEquals("Updated description", appt.getDescription());
    }

    @Test
    void testSetInvalidDescription() {

        Date futureDate =
                new Date(System.currentTimeMillis() + 1000000);

        Appointment appt = new Appointment(
                "12345", futureDate, "Valid description");

        assertThrows(IllegalArgumentException.class, () ->
                appt.setDescription(""));
    }
}