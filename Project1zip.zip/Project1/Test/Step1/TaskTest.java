package Step1;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

public class TaskTest {

    //VALID CASE

    @Test
    void testValidTask_AllFieldsCorrect() {
        Task task = new Task("12345", "ValidName", "Valid description");

        assertEquals("12345", task.getUniqueID());
        assertEquals("ValidName", task.getName());
        assertEquals("Valid description", task.getDescription());
    }

    //ID BRANCHES 

    @Test
    void testID_Null() {
        assertThrows(IllegalArgumentException.class,
                () -> new Task(null, "Name", "Description"));
    }

    @Test
    void testID_TooLong() {
        assertThrows(IllegalArgumentException.class,
                () -> new Task("12345678901", "Name", "Description"));
    }

    //NAME BRANCHES 

    @Test
    void testName_Null() {
        assertThrows(IllegalArgumentException.class,
                () -> new Task("123", null, "Description"));
    }

    @Test
    void testName_Empty() {
        assertThrows(IllegalArgumentException.class,
                () -> new Task("123", "", "Description"));
    }

    @Test
    void testName_TooLong() {
        assertThrows(IllegalArgumentException.class,
                () -> new Task("123",
                        "ThisNameIsDefinitelyLongerThanTwentyChars",
                        "Description"));
    }

    @Test
    void testName_MaxBoundary() {
        String name = "ABCDEFGHIJKLMNOPQRST"; // 20 chars

        Task task = new Task("123", name, "Description");

        assertEquals(name, task.getName());
    }

    //DESCRIPTION BRANCHES

    @Test
    void testDescription_Null() {
        assertThrows(IllegalArgumentException.class,
                () -> new Task("123", "Name", null));
    }

    @Test
    void testDescription_Empty() {
        assertThrows(IllegalArgumentException.class,
                () -> new Task("123", "Name", ""));
    }

    @Test
    void testDescription_TooLong() {
        String longDesc = "a".repeat(51);

        assertThrows(IllegalArgumentException.class,
                () -> new Task("123", "Name", longDesc));
    }

    @Test
    void testDescription_MaxBoundary() {
        String desc = "a".repeat(50);

        Task task = new Task("123", "Name", desc);

        assertEquals(desc, task.getDescription());
    }

    // SETTER BRANCHES

    @Test
    void testSetName_Valid() {
        Task task = new Task("123", "OldName", "Description");

        task.setName("NewName");

        assertEquals("NewName", task.getName());
    }

    @Test
    void testSetName_Invalid_Empty() {
        Task task = new Task("123", "OldName", "Description");

        assertThrows(IllegalArgumentException.class,
                () -> task.setName(""));
    }

    @Test
    void testSetDescription_Valid() {
        Task task = new Task("123", "Name", "OldDesc");

        task.setDescription("NewDesc");

        assertEquals("NewDesc", task.getDescription());
    }

    @Test
    void testSetDescription_Invalid_Empty() {
        Task task = new Task("123", "Name", "OldDesc");

        assertThrows(IllegalArgumentException.class,
                () -> task.setDescription(""));
    }

    @Test
    void testSetDescription_Invalid_Null() {
        Task task = new Task("123", "Name", "OldDesc");

        assertThrows(IllegalArgumentException.class,
                () -> task.setDescription(null));
    }
}