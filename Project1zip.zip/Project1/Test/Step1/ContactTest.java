package Step1;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

public class ContactTest {

    @Test
    void testValidContact() {

        Contact contact = new Contact(
                "12345",
                "Kay",
                "Padila",
                "1234567890",
                "1125 Pointloma Ave");

        assertEquals("12345", contact.getContactID());
        assertEquals("Kay", contact.getFirstName());
        assertEquals("Padila", contact.getLastName());
        assertEquals("1234567890", contact.getPhoneNumber());
        assertEquals("1125 Pointloma Ave", contact.getAddress());
    }

    //ID TESTS

    @Test
    void testNullID() {
        assertThrows(IllegalArgumentException.class, () ->
                new Contact(null, "Kay", "Padila", "1234567890", "Address"));
    }

    @Test
    void testIDTooLong() {
        assertThrows(IllegalArgumentException.class, () ->
                new Contact("12345678901", "Kay", "Padila", "1234567890", "Address"));
    }

    // FIRST NAME TESTS 

    @Test
    void testNullFirstName() {
        assertThrows(IllegalArgumentException.class, () ->
                new Contact("12345", null, "Padila", "1234567890", "Address"));
    }

    @Test
    void testFirstNameTooLong() {
        assertThrows(IllegalArgumentException.class, () ->
                new Contact("12345", "VeryLongFirstName", "Padila", "1234567890", "Address"));
    }

    @Test
    void testEmptyFirstName() {
        assertThrows(IllegalArgumentException.class, () ->
                new Contact("12345", "", "Padila", "1234567890", "Address"));
    }

    // LAST NAME TESTS

    @Test
    void testNullLastName() {
        assertThrows(IllegalArgumentException.class, () ->
                new Contact("12345", "Kay", null, "1234567890", "Address"));
    }

    @Test
    void testLastNameTooLong() {
        assertThrows(IllegalArgumentException.class, () ->
                new Contact("12345", "Kay", "VeryLongLastName", "1234567890", "Address"));
    }

    @Test
    void testEmptyLastName() {
        assertThrows(IllegalArgumentException.class, () ->
                new Contact("12345", "Kay", "", "1234567890", "Address"));
    }

    // PHONE TESTS 

    @Test
    void testNullPhone() {
        assertThrows(IllegalArgumentException.class, () ->
                new Contact("12345", "Kay", "Padila", null, "Address"));
    }

    @Test
    void testPhoneTooShort() {
        assertThrows(IllegalArgumentException.class, () ->
                new Contact("12345", "Kay", "Padila", "12345", "Address"));
    }

    @Test
    void testPhoneTooLong() {
        assertThrows(IllegalArgumentException.class, () ->
                new Contact("12345", "Kay", "Padila", "12345678901", "Address"));
    }

    // ADDRESS TESTS 

    @Test
    void testNullAddress() {
        assertThrows(IllegalArgumentException.class, () ->
                new Contact("12345", "Kay", "Padila", "1234567890", null));
    }

    @Test
    void testEmptyAddress() {
        assertThrows(IllegalArgumentException.class, () ->
                new Contact("12345", "Kay", "Padila", "1234567890", ""));
    }

    @Test
    void testAddressTooLong() {
        assertThrows(IllegalArgumentException.class, () ->
                new Contact(
                        "12345",
                        "Kay",
                        "Padila",
                        "1234567890",
                        "This address is definitely way too long for the system limit"));
    }

    // SETTER TESTS

    @Test
    void testSetValidFirstName() {
        Contact contact = new Contact(
                "12345", "Kay", "Padila", "1234567890", "Address");

        contact.setFirstName("Kayla");

        assertEquals("Kayla", contact.getFirstName());
    }

    @Test
    void testSetInvalidFirstName() {
        Contact contact = new Contact(
                "12345", "Kay", "Padila", "1234567890", "Address");

        assertThrows(IllegalArgumentException.class, () ->
                contact.setFirstName("VeryLongName"));
    }

    @Test
    void testSetValidLastName() {
        Contact contact = new Contact(
                "12345", "Kay", "Padila", "1234567890", "Address");

        contact.setLastName("Padila");

        assertEquals("Padila", contact.getLastName());
    }

    @Test
    void testSetInvalidLastName() {
        Contact contact = new Contact(
                "12345", "Kay", "Padila", "1234567890", "Address");

        assertThrows(IllegalArgumentException.class, () ->
                contact.setLastName("VeryLongName"));
    }

    @Test
    void testSetValidPhone() {
        Contact contact = new Contact(
                "12345", "Kay", "Padila", "1234567890", "Address");

        contact.setPhoneNumber("0987654321");

        assertEquals("0987654321", contact.getPhoneNumber());
    }

    @Test
    void testSetInvalidPhone() {
        Contact contact = new Contact(
                "12345", "Kay", "Padila", "1234567890", "Address");

        assertThrows(IllegalArgumentException.class, () ->
                contact.setPhoneNumber("123"));
    }

    @Test
    void testSetValidAddress() {
        Contact contact = new Contact(
                "12345", "Kay", "Padila", "1234567890", "Address");

        contact.setAddress("456 Oak Street");

        assertEquals("456 Oak Street", contact.getAddress());
    }

    @Test
    void testSetInvalidAddress() {
        Contact contact = new Contact(
                "12345", "Kay", "Padila", "1234567890", "Address");

        assertThrows(IllegalArgumentException.class, () ->
                contact.setAddress(""));
    }
}
